import NavBar from "../Navbar/NavBar";
import TopBar from "../TopBar/TopBar";

export default function Annonces(props){
    return (
       <>
            <TopBar/>
            <NavBar/>
       </>
        
    )
}