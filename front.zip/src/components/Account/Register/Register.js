import Signup from "../Signup/Signup";

export default function Register(props) {
    return (
        <section className="section appoinment">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-lg-6 ">
                        <div className="appoinment-content">
                            <img src="images/about/img-3.jpg" alt="" className="img-fluid"/>
                            <div className ="emergency">
                            <h2 className ="text-lg"><i className ="icofont-phone-circle text-lg"></i>+23 345 67980</h2>
                            </div>
                        </div>
                    </div>
                    <Signup/>
                </div>
            </div>
        </section>
    )
}