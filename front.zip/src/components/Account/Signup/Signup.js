import { useState } from "react"
import AuthServices from "../../../services/AuthServices/AuthServices"

export default function Signup(props) {
    const [cred , setCred] = useState({email : '' , password : ''})
    
    const updateField = (key,value)=>{
        cred[key] = value
        setCred(cred)
    }

    const Signup = ()=>{
        new AuthServices().signup(cred)
    }
    return (
        <div className="col-lg-6 col-md-10 ">
            <div className="appoinment-wrap mt-5 mt-lg-0">
                <h2 className="mb-2 title-color">Crée un Compte</h2>
                <p className="mb-4">Crée votre compte gratuitement et bénificiez vous de nos fonctionnalitées.</p>
                <form id="#" className="appoinment-form" method="post" action="#">
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="form-group">
                                <input name="nom" id="nom" type="text" className="form-control" placeholder="Nom" />
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="form-group">
                                <input name="prenom" id="prenom" type="text" className="form-control" placeholder="Prénom" />
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <input name="date_naissance" id="dateN" type="text" className="form-control" placeholder="Date de Naissance : dd/mm/yyyy" />
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <input name="CIN" id="cin" type="text" className="form-control" placeholder="Numéro de la carte d'identité Nationale" />
                            </div>
                        </div>


                        <div className="col-lg-12">
                            <div className="form-group">
                                <input name="numero_tele" id="phone" type="Number" className="form-control" placeholder="Numéro de Téléphone" />
                            </div>
                        </div>
                    </div>

                    <a className="btn btn-main btn-round-full" href="appoinment.html" >Crée Mon Compte<i className="icofont-simple-right ml-2  "></i></a>
                </form>
            </div>
        </div>
    )
}