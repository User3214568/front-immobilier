import React from "react"
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom"

import DashboardNavBar from "../DashboardNavBar/DashboardNavBar"
import ManagePosts from "../ManagePosts/ManagePosts"

export default class RootDashboard extends React.Component {

    constructor(props) {
        super(props)
        this.options = [
            { label: 'Mes Informations', path: "", icon: 'mdi-account-plus ', content: <ManagePosts/> },
            { label: 'Mes Reservations', path: "reservations", icon: 'mdi-home-modern ', content: <div>Mes Reservation</div> },
            { label: 'Mes Contract', path: "contracts", icon: 'mdi-briefcase-check', content: <div>Mes Contracts</div> },
            { label: 'Mes Annonces', path: "annonces", icon: 'mdi-book-open', content: <div>Mes Annonces</div> }
        ]
    }
    render() {
        const routes = this.options.map((value, key) => {
            return (
                <Route key={key} path={value.path} element={value.content}></Route>
            )
        })
        const options = this.options.map((value, key) => {

            return (
                <li key={key} className="nav-item">
                    <Link to={value.path} className="nav-link">
                        <span className="menu-title">{value.label}</span>
                        <i className={"mdi " + value.icon + " menu-icon"}></i>
                    </Link>
                </li>
            )
        })
        return (
            <div className="container-scroller">
                <DashboardNavBar/>
                <div className="container-fluid page-body-wrapper">

                    <nav className="sidebar sidebar-offcanvas" id="sidebar">
                        <ul className="nav">
                            <li className="nav-item nav-profile">
                                <a href="#" className="nav-link">
                                    <div className="nav-profile-image">
                                        <img src="images/faces/face1.jpg" alt="profile" />
                                        <span className="login-status online"></span>
                                    </div>
                                    <div className="nav-profile-text d-flex flex-column">
                                        <span className="font-weight-bold mb-2">David Grey. H</span>
                                        <span className="text-secondary text-small">Project Manager</span>
                                    </div>
                                    <i className="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                                </a>
                            </li>
                            <li>
                                <span className="nav-link  border-bottom">
                                    <span className="border-bottom">
                                        <h6 className="font-weight-normal mb-1">Mes Actions</h6>
                                    </span>
                                </span>
                            </li>
                            {options}
                            <span className="nav-link border-bottom">
                                <span className="border-bottom">
                                    <h6 className="font-weight-normal mb-1">Mon Compte</h6>
                                </span>
                            </span>
                            <li className="nav-item">
                                <a href="" className="nav-link">
                                    <span className="menu-title">Se Déconnecter</span>
                                    <i className="mdi mdi-logout  menu-icon"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>

                    <div className="main-panel">
                        <div className="content-wrapper">
                            <Routes>
                                {routes}
                            </Routes>
                        </div>

                        <footer className="footer">
                            <div className="d-sm-flex justify-content-center justify-content-sm-between">
                                <span className="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Gestion des Immobiliers - Projet JEE 2022</span>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
        )
    }

}