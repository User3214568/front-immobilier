import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import Select from 'react-select'

export default function ManagePostsModal(props) {
    const [villes, setVilles] = useState([])
    // Fetch for Morocco Cities
    useEffect(() => {
        fetch("https://raw.githubusercontent.com/mehdibo/morocco-cities/master/cities.json").then(response => {
            response.json().then(value => {
                const res = value.cities.data.map((v, k) => {
                    return { value: v.names.fr, label: v.names.fr }
                })
                setVilles(res)
            })
        })
    }, [])
    const typeImmobles = [
        { label: 'Villa', value: 'Villa' },
        { label: 'Appartement', value: 'Appartement' },
        { label: 'Maison', value: 'Maison' }
    ]
    return (
        <Modal size="lg" show={true} >
            <Modal.Body>
                <div class="row justify-content-center ">

                    <div class="col-12">
                        <h4 class="card-title">Ajouter une Annonce</h4>
                        <hr class="dropdown-divider" />
                        <form class="container forms-sample">
                            <p class="card-description">
                                Veuillez saisir les informations conernant votre annonce
                            </p>
                            <div className="row">
                                <div className="col-md-6 sidebar-widget  mb-3">
                                    <h5>Ttire de l'annonce</h5>
                                    <textarea class="form-control"  rows="4"></textarea>
                                </div>

                                <div className="col-md-6 sidebar-widget  mb-3">
                                    <h5>Description</h5>
                                    <textarea class="form-control"  rows="4"></textarea>
                                </div>
                                
                                <div className="col-md-6 sidebar-widget  mb-3">
                                    <h5>Type d'immobilier</h5>
                                    <Select
                                        options={typeImmobles}
                                        isMulti={false}
                                        className="basic-select"
                                        classNamePrefix="select"
                                    >

                                    </Select>

                                </div>

                                <div className="col-md-6 sidebar-widget  mb-3">
                                    <h5>Ville</h5>
                                    <Select
                                        options={villes}
                                        isMulti={false}
                                        className="basic-select"
                                        classNamePrefix="select"

                                    ></Select>
                                </div>
                                <div className="col-md-6 sidebar-widget  mb-3">
                                    <h5>Prix de location / vente</h5>
                                    <input type="text" class="form-control" placeholder="Prix" />
                                </div>

                            </div>
                                <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                                <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </Modal.Body>
        </Modal>
    )
}