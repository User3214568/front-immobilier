import { useEffect, useState } from "react"
import AnnonceServices from "../../../services/AnnonceServices/AnnonceServices"
import Annonce from "../../Annonce/Annonce"
import ManagePostsModal from "./ManagePostsModal/ManagePostsModal"

export default function ManagePosts(props) {

    const [annonces, setAnnonces] = useState([])
    useEffect(async () => {
        const loadedPosts = await new AnnonceServices().getMyAnnonce()
        setAnnonces(loadedPosts)
    }, [])
    const postsView = annonces.map((value, index) => {
        return (
            <Annonce key={index} post={value} clickEvent={() => { }} />
        )
    })
    return (
        <>

            <div className="page-header">
                <h3 className="page-title">
                    <span className="page-title-icon bg-gradient-primary text-white mr-2">
                        <i className="mdi mdi-book-open"></i>
                    </span>
                    Géré mes Annonces
                </h3>
                <nav aria-label="breadcrumb">
                    <ul className="breadcrumb">
                        <li className="breadcrumb-item active" aria-current="page">
                            <button type="button" className="btn btn-outline-primary btn-icon-text">
                                <i className="mdi mdi-plus btn-icon-prepend"></i>
                                Ajouter Annonce
                            </button>
                        </li>
                    </ul>
                </nav>
            </div>
            <div>
                {
                    annonces.length < 1 &&
                    <div className="row">
                        <div className="col-12">
                            <span className="d-flex p-5 align-items-center text-center purchase-popup">
                                <p>Vous n'avez aucune annonce à afficher.</p>
                            </span>
                        </div>
                    </div>
                }
                <div className="row">
                    {
                        annonces.length >= 1 && postsView
                    }
                </div>
            </div>
            <ManagePostsModal header="Something"/>
        </>
    )
}