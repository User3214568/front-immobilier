import image from '../../assets/images/logo.png'

export default function NavBar(props){

    return (
        <nav className="navbar navbar-expand-lg navigation" id="navbar">
		<div className="container">
		 	 <a className="navbar-brand" href="index.html">
			  	<img src={image} alt="" className="img-fluid"/>
			  </a>

		  	<button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarmain" aria-controls="navbarmain" aria-expanded="false" aria-label="Toggle navigation">
			<span className="icofont-navigation-menu"></span>
		  </button>
	  
		  <div className="collapse navbar-collapse" id="navbarmain">
			<ul className="navbar-nav ml-auto">
			  <li className="nav-item active">
				<a className="nav-link" href="index.html">Acceuil</a>
			  </li>
			   <li className="nav-item"><a className="nav-link" href="/annonces">List des Annonces</a></li>
			    <li className="nav-item"><a className="nav-link" href="service.html">Services</a></li>

			   <li className="nav-item"><a className="nav-link" href="contact.html">Contact</a></li>
			    <li className="nav-item dropdown">
					<a className="nav-link dropdown-toggle" href="department.html" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i className="icofont-thin-down"></i>
						Acceder à votre compte
					</a>
					<ul className="dropdown-menu" aria-labelledby="dropdown02">
						<li><a className="dropdown-item" href="">Crée un Compte</a></li>
						<li><a className="dropdown-item" href="/login">Se Connecter</a></li>
					</ul>
			  	</li>

			  
			</ul>
		  </div>
		</div>
	</nav>
    )
}