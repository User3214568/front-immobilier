export default class AnnonceServices {


    async getAll(){
        return [
            {
                id_annonce : "Q4q5A45DS", 
                titre : "Villa 100 Km² à vendre",
                date_annonce : "20-10-2015",
                ville : 'Casablanca',
                typeAnnonce : "Villa",
                description : "Ceci est une description de la villa",
                photos : ["https://actualite.seloger-construire.com/sites/default/files/article/image/maison-en-l-seloger-construire.jpg"],
                prix : 152000,
                typeVente : "Location",
                estReserver : false,
            }
        ]
    }
    async getMyAnnonce(){
        return [
            {
                id_annonce : "Q4q5A45DS", 
                titre : "Villa 100 Km² à vendre",
                date_annonce : "20-10-2015",
                ville : 'Casablanca',
                typeAnnonce : "Villa",
                description : "Ceci est une description de la villa",
                photos : ["https://actualite.seloger-construire.com/sites/default/files/article/image/maison-en-l-seloger-construire.jpg"],
                prix : 152000,
                typeVente : "Location",
                estReserver : false,
            }
        ]
    }
    async reserver(id){

    }
    async delete(id){}
    async validate(id){}
    async update(post){} 

}