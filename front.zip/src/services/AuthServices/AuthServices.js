export default class AuthServices {
    async login(creds){
       return true
    }
    async signup(account){
        
    }
}