import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router , Routes , Route}  from 'react-router-dom';
import Home from './components/Home/Home';
import ListAnnonce from './components/ListAnnonces/ListAnnonces';
import Login from './components/Account/Login/Login';
import RootDashboard from './components/Dashboard/RootDashboard/RootDashboard';

function App() {
  return (
    <Router>
        <Routes>
          <Route path="/annonces" element={<ListAnnonce/>} />
          <Route path="/login" element={<Login/>}/>
          <Route path="/dashboard/*" element={<RootDashboard/>} />
          <Route path="/"  element={<Home/>}/>
        </Routes>
    </Router>
  );
}

export default App;
